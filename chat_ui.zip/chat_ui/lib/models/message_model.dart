import 'package:chat_ui/models/user_model.dart';

class Message {
  final User sender;
  final String time; //Would usually be type DateTime or Firebase
  final String text;
  final bool isLiked;
  final bool unread;

  Message({
    this.sender,
    this.time,
    this.text,
    this.isLiked,
    this.unread,
  });
}

//YOU - current user
final User currentUser =
    User(id: 0, name: 'Current User', imageUrl: 'assets/images/traveler.png');

final User childe =
    User(id: 1, name: 'Childe', imageUrl: 'assets/images/childe.png');

final User yun =
    User(id: 2, name: 'Chongyun', imageUrl: 'assets/images/yun.png');

final User ning =
    User(id: 3, name: 'Ningguang', imageUrl: 'assets/images/ning.png');

final User xian =
    User(id: 4, name: 'XiangLing', imageUrl: 'assets/images/xian.png');

final User rose =
    User(id: 5, name: 'Sucrose', imageUrl: 'assets/images/rose.png');

final User diluc =
    User(id: 6, name: 'Diluc', imageUrl: 'assets/images/diluc.png');

List<User> favorites = [yun, diluc, ning, xian, rose, childe];

List<Message> chats = [
  Message(
    sender: childe,
    time: '2:00 AM',
    text: 'Zhongli was waiting for you at Liyue Harbor.',
    isLiked: false,
    unread: true,
  ),
  Message(
    sender: yun,
    time: '12:00 AM',
    text:
        'I heard there was a ghost that needs to be exorcised. Happened to know the location?',
    isLiked: false,
    unread: true,
  ),
  Message(
    sender: xian,
    time: '10:30 PM',
    text: 'Traveler, that was fun, lets go on an adventure again next time',
    isLiked: false,
    unread: true,
  ),
  Message(
    sender: ning,
    time: '08:49 PM',
    text:
        'Will you spare me a moment of your time and have a nice chat among us ladies?',
    isLiked: false,
    unread: true,
  ),
  Message(
    sender: diluc,
    time: '04:50 PM',
    text: 'Venti is drunk at the tavern, he is getting out of hand.',
    isLiked: false,
    unread: false,
  ),
];

//Chat screen
List<Message> messages = [
  Message(
    sender: childe,
    time: '2:04 AM',
    text: 'Where were you Ojou-chan?',
    isLiked: false,
    unread: false,
  ),
  Message(
    sender: currentUser,
    time: '2:03 AM',
    text: 'I was on an adventure with XiangLing',
    isLiked: false,
    unread: true,
  ),
  Message(
    sender: childe,
    time: '2:00 AM',
    text: 'Where were you Ojou-chan?',
    isLiked: true,
    unread: true,
  ),
];
